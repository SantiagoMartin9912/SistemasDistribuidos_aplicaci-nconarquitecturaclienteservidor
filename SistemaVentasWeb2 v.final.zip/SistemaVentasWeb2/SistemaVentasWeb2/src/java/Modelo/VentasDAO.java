package Modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author santi
 */
public class VentasDAO {

    Connection con;
    Conexion cn;
    PreparedStatement ps;
    ResultSet rs;
    
    int r;

}
